// var arr1: number[];
// var arr2: Array<number>;

// var nArr = [10, 20, 30, 40, 50];
// var dArr = [10 ,"ABC", true];

// var aData: any[];
// var aData: Array<any>;

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Ram" },
    { id: 3, name: "Abhijeet" },
    { id: 4, name: "Pravin" },
    { id: 5, name: "Subodh" }
];

// console.log(employees.find(item => item.id === 3));

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${employees[i].name}`);
// }

// for(const key in employees){
//     console.log(`${employees[key].name}`);
// }

// employees.forEach((item) => {
//     console.log(`${item.name}`);
// });

for (const item of employees) {
    console.log(`${item.name}`);
}