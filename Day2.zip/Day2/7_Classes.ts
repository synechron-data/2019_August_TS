// class Employee {
//     private _name: string;

//     // Multiple constructor implementations are not allowed.
//     // constructor() {
//     //     this._name = "NA";
//     // }

//     constructor(name = "NA") {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     // Donot use Lambda as Class Member (Increases Memory Usage)
//     // getName = () => {
//     //     return this._name;
//     // }

//     setName(n: string) {
//         this._name = n;
//     }
// }

// // var e1 = new Employee();
// var e1 = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// --------------------------------------------- Properties
// Properties enable developers to expose private class members and 
// to encapsulate the logic of getting or setting that member. 

// class Employee {
//     private _name: string;
//     private _age: number;

//     constructor(name = "NA", age = 0) {
//         this._name = name;
//         this._age = age;
//     }

//     get Name() {
//         return this._name;
//     }

//     set Name(n: string) {
//         this._name = n;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(a: number) {
//         this._age = a;
//     }
// }

// var e1 = new Employee("Manish");
// console.log(e1.Name);
// console.log(e1.Age);
// e1.Name = "Abhijeet";
// e1.Age = 36;
// console.log(e1.Name);
// console.log(e1.Age);

// ----------------------------------- Parameter Properties/Members
// Parameter properties let us create and initialize member variables in one place. 
// It is a shorthand for creating member variables.

// class Employee {
//     constructor(private _name = "NA", private _age = 0) { }

//     get Name() {
//         return this._name;
//     }

//     set Name(n: string) {
//         this._name = n;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(a: number) {
//         this._age = a;
//     }
// }

// var e1 = new Employee("Manish");
// console.log(e1.Name);
// console.log(e1.Age);
// e1.Name = "Abhijeet";
// e1.Age = 36;
// console.log(e1.Name);
// console.log(e1.Age);

// // ------------------------------------------------------- Static Members

// // class BankAccount {
// //     constructor(private _bankname: string, private _accName: string) { }

// //     get BankName(): string {
// //         return this._bankname;
// //     }

// //     get AccountName(): string {
// //         return this._accName;
// //     }
// // }

// class BankAccount {
//     private static _bankname: string;

//     constructor(private _accName: string) { }

//     static set BankName(bankname: string) {
//         BankAccount._bankname = bankname;
//     }

//     get BankName(): string {
//         return BankAccount._bankname;
//     }

//     get AccountName(): string {
//         return this._accName;
//     }
// }

// BankAccount.BankName = "ICICI";

// var a1 = new BankAccount("Manish");
// console.log("Bank Name: ", a1.BankName);
// console.log("Account Holder Name: ", a1.AccountName);

// var a2 = new BankAccount("Abhijeet");
// console.log("Bank Name: ", a2.BankName);
// console.log("Account Holder Name: ", a2.AccountName);

// ------------------------------------------------------- Static Members

class BankAccount {
    private static _bankname: string;

    constructor(private readonly _accNumber: number, private _accName: string) { }

    static set BankName(bankname: string) {
        BankAccount._bankname = bankname;
    }

    get BankName(): string {
        return BankAccount._bankname;
    }

    get AccountNumber(): number {
        // this._accNumber = 100;
        return this._accNumber;
    }

    get AccountName(): string {
        return this._accName;
    }
}

BankAccount.BankName = "ICICI";

var a1 = new BankAccount(1, "Manish");
console.log("Bank Name: ", a1.BankName);
console.log("Account Number: ", a1.AccountNumber);
console.log("Account Holder Name: ", a1.AccountName);

var a2 = new BankAccount(2, "Abhijeet");
console.log("Bank Name: ", a2.BankName);
console.log("Account Number: ", a2.AccountNumber);
console.log("Account Holder Name: ", a2.AccountName);