function getLength(arg) {
    console.log(arg.length);
}
getLength("abc");
getLength(["abc"]);
getLength([1, 2, 3, 4, 5, 6]);
