// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// class Person implements IPerson {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 36);
// console.log(p1.greet("Hi"));

// let p2: IPerson = new Person("Ramakant", 36);
// console.log(p1.greet("Hello"));

// // --------------------------------------- Multiple Interface Implementation

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// class Person implements IPerson, IWork {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am working..";
//     }
// }

// let p1: Person = new Person("Abhijeet", 36);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// --------------------------------------- Interface can Extend other interface

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): void;
// }

// class Customer implements ICustomer, IWork {

//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }

//     doShopping(): void {
//         console.log("Let's go to the mall..")
//     }

//     doWork(): string {
//         return "I am working..";
//     }
// }

// // let p1: Customer = new Customer("Abhijeet", 36);
// // console.log(p1.greet("Hi"));
// // console.log(p1.doWork());
// // p1.doShopping();

// let p1: ICustomer = new Customer("Abhijeet", 36);

// let p2: IWork = new Customer("Abhijeet", 36);

// let p3: IPerson = new Customer("Abhijeet", 36);

// ------------------------------------ Interface extend class

// class Vehicle {
//     constructor(public make: string) { }

//     getMake() {
//         return this.make;
//     }
// }

// class Engine {
//     constructor(public manufacturer: string) { }

//     getManufacturer() {
//         return this.manufacturer;
//     }
// }

// interface IFourWheeler extends Vehicle, Engine {}

// class FourWheeler implements IFourWheeler {
//     public make: string;
//     public manufacturer: string;

//     getMake(): string {
//         throw new Error("Method not implemented.");
//     }    
    
//     getManufacturer(): string {
//         throw new Error("Method not implemented.");
//     }
// }