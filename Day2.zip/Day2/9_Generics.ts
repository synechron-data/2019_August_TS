// Generics allows you to create a component that can work over a variety of types 
// rather than a single one. 

// class Queue {
//     private data: number[] = [];

//     push(d: number) {
//         this.data.push(d);
//     }

//     pop(): number {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue();
// q1.push(10);
// q1.push(20);
// q1.push(30);

// console.log(q1.pop());
// console.log(q1.pop());
// console.log(q1.pop());

// -----------------------------------------------------
// class Queue {
//     private data: any[] = [];

//     push(d: any) {
//         this.data.push(d);
//     }

//     pop(): any {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue();
// q1.push(10);
// q1.push("abc");
// q1.push(20);

// var q2 = new Queue();
// q2.push("abc");
// q2.push("xyz");

// console.log(q1.pop());
// console.log(q1.pop());

// console.log(q2.pop());
// console.log(q2.pop());

// ----------------------------------------------

// class Queue<T> {
//     private data: T[] = [];

//     push(d: T) {
//         this.data.push(d);
//     }

//     pop(): T {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue<number>();
// q1.push(10);
// q1.push(20);

// var q2 = new Queue<string>();
// q2.push("abc");
// q2.push("xyz");

// console.log(q1.pop().toFixed());
// console.log(q1.pop());

// console.log(q2.pop().toUpperCase());
// console.log(q2.pop());

// var arr = new Array<number>();

// ------------------------------------------- Constraints
interface ILength {
    length: number;
}

function getLength<T extends ILength>(arg: T) {
    console.log(arg.length);
}

getLength<string>("abc");
getLength<string[]>(["abc"]);
getLength<number[]>([1, 2, 3, 4, 5, 6]);
// getLength<number>(10);