var dataRow = [1, "ABC"];
for (var _i = 0, dataRow_1 = dataRow; _i < dataRow_1.length; _i++) {
    var item = dataRow_1[_i];
    console.log(item);
}
