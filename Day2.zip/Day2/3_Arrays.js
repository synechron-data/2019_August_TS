var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Ram" },
    { id: 3, name: "Abhijeet" },
    { id: 4, name: "Pravin" },
    { id: 5, name: "Subodh" }
];
for (var _i = 0, employees_1 = employees; _i < employees_1.length; _i++) {
    var item = employees_1[_i];
    console.log("" + item.name);
}
