// const area = function (rect: { h: number, w?: number }) {
//     rect.w = rect.w || rect.h;
//     return rect.h * rect.w;
// }

// let s1 = { h: 20, w: 20 };
// console.log(area(s1));

// let s2 = { h: 10 };
// console.log(area(s2));

// let s3 = { h: 20, w: 20, d: 30 };
// console.log(area(s3));

// ------------------------------------------------ Interface

// interface Rectangle {
//     h: number;
//     w?: number;
// }

// const area = function (rect: Rectangle) {
//     rect.w = rect.w || rect.h;
//     return rect.h * rect.w;
// }

// let s1: Rectangle = { h: 20, w: 20 };
// console.log(area(s1));

// let s2: Rectangle = { h: 10 };
// console.log(area(s2));

// // let s3: Rectangle = { h: 20, w: 20, d: 30 };
// // console.log(area(s3));

// ------------------------------------------------ With Method

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// let p1: IPerson = {
//     name: "Abhijeet",
//     age: 36,
//     greet: function (m) {
//         return "Hello";
//     }
// };

// let p2: IPerson = {
//     name: "Abhijeet",
//     age: 36,
//     greet: function (m) {
//         return "Hi";
//     }
// };

// ------------------------------ Declaration Merging (Interface Merging)

// interface Shape {
//     height: number;
// }

// interface Shape {
//     width: number;
// }

// let s1: Shape = { height: 10, width: 20 };