// Types of Decorators
// Class Decorator <T extends Function>(target:T) => T | void
// Property Decorator (target: Object, propertyKey: string | symbol) => void;
// Method Decorator <T>(target: Object, propertyKey: string | symbol, descriptor: TypedPropertyDescriptor<T>) => TypedPropertyDescriptor<T> | void;
// Parameter Decorator (target: Object, propertyKey: string | symbol, parameterIndex: number) => void;

// --------------------------------
// function log<T>(target: T, propertyKey: string, descriptor: any) {
//     var originalMethod = descriptor.value;

//     descriptor.value = function (...args: any[]) {
//         var a = args.map(arg => JSON.stringify(arg)).join();
//         console.log(`${propertyKey} is called with arguments as ${a}`);
//         var result;
//         try {
//             result = originalMethod.apply(this, args);
//         }
//         catch (e) {
//             console.log("Exception handled.....");
//         }
//         return result;
//     }

//     return descriptor;
// }

// class Calculate {
//     @log
//     add(x: number, y: number) {
//         // return x + y;
//         throw Error("Testing....");
//     }

//     @log
//     sub(x: number, y: number) {
//         return x - y;
//     }
// }

// var c = new Calculate();
// console.log(c.add(23, 45));
// console.log(c.sub(2, 4));

function CityDecorator<T extends { new(...args: any[]): {} }>(target: T) {
    return class extends target {
        city = "Pune"
    }
}

@CityDecorator
class MyPerson {
    name: string;

    constructor(n = "NA") {
        this.name = n;
    }
}

var c = new MyPerson("Manish");
console.log(c);