// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// var arr: number[] = [10, 20, 30, 40, 50, 60];

// var dataArr: (number | string)[] = [1, "ABC"];
// dataArr = ["PQR", 2];
// dataArr = ["PQR", "XYZ"];
// dataArr = [1, 2, 3, 4];
// dataArr = ["PQR", 2, "XYZ"];

// Tuple
var dataRow: [number, string] = [1, "ABC"];
// dataRow = ["PQR", 2];
// dataRow = ["PQR", "XYZ"];
// dataRow = [1, 2, 3, 4];
// dataRow = [1, "ABC", "XYZ"];

for (const item of dataRow) {
    console.log(item);
}