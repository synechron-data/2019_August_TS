var i = 10;
console.log("Before, i is:", i);
for (var i_1 = 0; i_1 < 5; i_1++) {
    console.log("Inside, i is:", i_1);
}
console.log("After, i is:", i);
