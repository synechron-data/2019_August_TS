var obj = { id: 1, name: "Manish" };
console.log(obj);
obj.id = 100;
console.log(obj);
