// ------------------------------- Array Spread

// var numArr1 = [10, 20, 30];

// // var numArr2 = numArr1.slice();
// // var numArr2 = [...numArr1];
// // numArr2[0] = 1000;

// // console.log(numArr1);
// // console.log(numArr2);

// var numArr2 = [40, 50];

// var numArr3 = [...numArr1, ...numArr2];

// console.log(numArr3)

// ------------------------------- Object Spread

var emp1 = { id: 1, name: "Manish", city: "Pune" };

var emp2 = { ...emp1 };
emp2.id = 100;

console.log("emp1 - ", emp1);
console.log("emp2- ", emp2);