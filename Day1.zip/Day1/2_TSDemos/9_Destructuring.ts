// // --------------------- Object Destructuring
// var emp = { id: 1, ename: "Manish", city: "Pune", state: "MH", pin: 411021 };

// // var id = emp.id;
// // var ename = emp.ename;

// // var { id, ename } = emp;
// var { id, ename, ...address } = emp;

// console.log("Id: ", id);
// console.log("Name: ", ename);
// console.log("Address: ", address);

// --------------------------------- Array Destructuring
var numArr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// var x = numArr[0];
// var y = numArr[2];

// var [x, , y] = numArr;
// var [x, , y, ...z] = numArr;

// console.log("x = " + x + ", y = " + y);
// console.log("z = " + z);

// var [x, , y] = numArr;
// console.log(`Before Swap, x = ${x},



//             y = ${y}`);

// Template Literal (`` - Back Tick)
var [x, , y] = numArr;
console.log(`Before Swap, x = ${x}, y = ${y}`);

[y, x] = [x, y];

console.log(`After Swap, x = ${x}, y = ${y}`);
