// const env = "development";
// console.log(env);

// if (true) {
//     const env = "production";
//     console.log(env);
// }

const obj = { id: 1, name: "Manish" };

console.log(obj);
obj.id = 100;
// obj = { id: 100 };          //Compile Time Error
console.log(obj);