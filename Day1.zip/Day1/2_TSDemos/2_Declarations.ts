// Implictly Typed
// var data = 10;
// data = "ABC";

// var data;
// data = 10;
// data = "ABC";

// Explictly Typed
// var age: number;
// age = 10;
// age = "ABC";

var age: number = 10;

function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
// console.log(add(2, "ABC"));
// console.log(add("ABC", "XYZ"));