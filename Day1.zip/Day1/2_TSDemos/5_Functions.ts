// console.log(d);
// let d;

Show();

function Show(): void {
    console.log("Show Completed...");
}

// let f1: void;
// f1 = 123;

// let f2: never;
// f2 = 123;

// let f3: never = (function () {
//     throw new Error("Testing Never...")
// })();

// Fn Declaration
// function Show(): void {
//     console.log("Show Completed...");
// }


// Fn Expression
// Show();

// var Show = function () {
//     console.log("Show Completed...");
// }

// function add1(x: number, y: number): number {
//     return x + y;
// }

// const add2 = function (x: number, y: number): number {
//     return x + y;
// }

// let f: number;
// f = 10;

// let hello: () => void;

// let add3: (a: number, b: number) => number;
// add3 = function (x: number, y: number): number {
//     return x + y;
// }

// let add4: (a: number, b: number) => number;
// add4 = (x: number, y: number): number => {
//     return x + y;
// }

// let add5: (a: number, b: number) => number;
// add5 = (x, y) => {
//     return x + y;
// }

// let add6: (a: number, b: number) => number;
// add6 = (x, y) => x + y;

// console.log(add1(2, 3));
// console.log(add2(2, 3));
// console.log(add3(2, 3));
// console.log(add4(2, 3));
// console.log(add5(2, 3));
// console.log(add6(2, 3));

// Lambdas replaces anonymous functions
// Widely used in callbacks

// var employeeArr = [
//     { id: 1, name: "ABC", city: "Pune" },
//     { id: 2, name: "XYZ", city: "Mumbai" },
//     { id: 3, name: "PQR", city: "Pune" }
// ];

// var resultArr = [];

// for (let i = 0; i < employeeArr.length; i++) {
//     if(employeeArr[i].city === "Pune")
//         resultArr.push(employeeArr[i]);    
// }

// function filterFn(item:any, index:number, arr:any[]){
//     return item.city === "Pune";
// }
// var resultArr = employeeArr.filter(filterFn);

// var resultArr = employeeArr.filter(function (item: any, index: number, arr: any[]) {
//     return item.city === "Pune";
// });

// var resultArr = employeeArr.filter((item, index, arr) => {
//     return item.city === "Pune";
// });

// var resultArr = employeeArr.filter((item, index, arr) => item.city === "Pune");

// var resultArr = employeeArr.filter((item) => item.city === "Pune");

// console.log(resultArr);

// -----------------------------------------

// IIFE
// var r = function () {
//     // throw new Error("Testing Never...")
//     console.log();
// }

// Dev1
// function test(): never {
//     while (true) {
//         console.log(new Date().toTimeString());
//     }
// }

// // Dev2
// test();

// var t1: number = null;
// var t2: never = null;

// var t1 = 10;
// var t2 = new Number(10);

// console.log(typeof(t1));
// console.log(typeof(t2));