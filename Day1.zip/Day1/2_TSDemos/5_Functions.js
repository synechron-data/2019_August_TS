Show();
function Show() {
    console.log("Show Completed...");
}
