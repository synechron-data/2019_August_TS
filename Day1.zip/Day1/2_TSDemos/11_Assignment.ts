function Reverse(word: string): string[];
function Reverse(wordArr: string[]): string[];

function Reverse(strOrarr: (string | string[])) {
    if (typeof strOrarr == "string")
        return strOrarr.split("").reverse();
    else
        return strOrarr.slice().reverse();
}

console.log(Reverse("Manish"));
console.log(Reverse(["PQR", "XYZ", "ABC"]));