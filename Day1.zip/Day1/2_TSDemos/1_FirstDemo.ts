class Program {
    static main(args: string): void {
        console.log("Hello, ", args);
    }
}

Program.main("Synechron");