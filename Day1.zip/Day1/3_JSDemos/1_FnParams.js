function hello(name) {
    console.log("Hello,", name);
}

hello("Synechron");
hello();
hello("Synechron", "Pune");
