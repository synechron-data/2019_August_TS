var Employee = (function(){
    function Employee(n) {
        this._name = n;
    }
    
    Employee.prototype.getName = function () {
        return this._name;
    }
    
    Employee.prototype.setName = function (n) {
        this._name = n;
    }

    return Employee;
})();

var e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());

var e2 = new Employee("Subodh");
console.log(e2.getName());
e2.setName("Ramakant");
console.log(e2.getName());

